package dev.zihan.hardcorecreative;

import net.fabricmc.api.ClientModInitializer;

public final class HardcoreCreativeClient implements ClientModInitializer {
   public void onInitializeClient() {
      // The vanilla F3+F4 game mode switcher now works through server-side permission mixins.
   }
}
