package dev.zihan.hardcorecreative;

import dev.zihan.hardcorecreative.command.HardcoreCreativeCommand;
import dev.zihan.hardcorecreative.event.PlayerEventHandler;
import dev.zihan.hardcorecreative.util.LogUtils;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import org.slf4j.Logger;

public final class HardcoreCreativeMod implements ModInitializer {
   public static final String MOD_ID = "hardcorecreative";
   public static final String MOD_NAME = "Hardcore Creative Access";
   public static final Logger LOGGER = LogUtils.logger();

   public void onInitialize() {
      ModConfig.load();
      CommandRegistrationCallback.EVENT.register((CommandRegistrationCallback)(dispatcher, registryAccess, environment) -> HardcoreCreativeCommand.register(dispatcher));
      PlayerEventHandler.register();
      LOGGER.info("{} initialized for Fabric worlds.", "Hardcore Creative Access");
   }
}
