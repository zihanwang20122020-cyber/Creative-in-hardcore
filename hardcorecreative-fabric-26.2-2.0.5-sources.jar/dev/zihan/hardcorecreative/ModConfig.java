package dev.zihan.hardcorecreative;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;

public final class ModConfig {
   private static final String FILE_NAME = "hardcorecreative.properties";
   private static volatile boolean autoAuthorizeSingleplayerOwner = true;
   private static volatile boolean autoRestoreCreativeOnLogin = true;
   private static volatile boolean forceSurvivalOnRevoke = true;
   private static volatile boolean allowCreativeAccess = true;
   private static volatile boolean verboseLogging = false;
   private static volatile int adminPermissionLevel = 2;
   private static volatile boolean defaultNonOpAccess = false;

   private ModConfig() {
   }

   public static synchronized void load() {
      Path path = configPath();

      try {
         Files.createDirectories(path.getParent());
         if (!Files.exists(path, new LinkOption[0])) {
            writeDefaultFile(path);
         }

         List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
         resetDefaults();

         for(String rawLine : lines) {
            String line = rawLine.trim();
            if (!line.isEmpty() && !line.startsWith("#")) {
               int separator = line.indexOf(61);
               if (separator > 0) {
                  String key = line.substring(0, separator).trim();
                  String value = line.substring(separator + 1).trim();
                  applyValue(key, value);
               }
            }
         }

      } catch (IOException exception) {
         throw new IllegalStateException("Failed to load Hardcore Creative Access config.", exception);
      }
   }

   public static synchronized void reload(MinecraftServer server) {
      load();
   }

   public static boolean autoAuthorizeSingleplayerOwner() {
      return autoAuthorizeSingleplayerOwner;
   }

   public static boolean autoRestoreCreativeOnLogin() {
      return autoRestoreCreativeOnLogin;
   }

   public static boolean forceSurvivalOnRevoke() {
      return forceSurvivalOnRevoke;
   }

   public static boolean allowCreativeInHardcore() {
      return allowCreativeAccess;
   }

   public static boolean allowCreativeAccess() {
      return allowCreativeAccess;
   }

   public static boolean verboseLogging() {
      return verboseLogging;
   }

   public static int adminPermissionLevel() {
      return adminPermissionLevel;
   }

   public static boolean defaultNonOpAccess() {
      return defaultNonOpAccess;
   }

   private static void applyValue(String key, String value) {
      switch (key) {
         case "autoAuthorizeSingleplayerOwner" -> autoAuthorizeSingleplayerOwner = parseBoolean(value, autoAuthorizeSingleplayerOwner);
         case "autoRestoreCreativeOnLogin" -> autoRestoreCreativeOnLogin = parseBoolean(value, autoRestoreCreativeOnLogin);
         case "forceSurvivalOnRevoke" -> forceSurvivalOnRevoke = parseBoolean(value, forceSurvivalOnRevoke);
         case "allowCreativeAccess", "allowCreativeInHardcore" -> allowCreativeAccess = parseBoolean(value, allowCreativeAccess);
         case "verboseLogging" -> verboseLogging = parseBoolean(value, verboseLogging);
         case "adminPermissionLevel" -> adminPermissionLevel = parseInt(value, adminPermissionLevel, 0, 4);
         case "defaultNonOpAccess" -> defaultNonOpAccess = parseBoolean(value, defaultNonOpAccess);
      }

   }

   private static boolean parseBoolean(String value, boolean defaultValue) {
      return switch (value.toLowerCase()) {
         case "true", "yes", "1", "on" -> true;
         case "false", "no", "0", "off" -> false;
         default -> defaultValue;
      };
   }

   private static int parseInt(String value, int defaultValue, int min, int max) {
      try {
         int parsed = Integer.parseInt(value);
         return Math.max(min, Math.min(max, parsed));
      } catch (NumberFormatException ignored) {
         return defaultValue;
      }
   }

   private static void resetDefaults() {
      autoAuthorizeSingleplayerOwner = true;
      autoRestoreCreativeOnLogin = true;
      forceSurvivalOnRevoke = true;
      allowCreativeAccess = true;
      verboseLogging = false;
      adminPermissionLevel = 2;
      defaultNonOpAccess = false;
   }

   private static Path configPath() {
      return FabricLoader.getInstance().getConfigDir().resolve("hardcorecreative.properties");
   }

   private static void writeDefaultFile(Path path) throws IOException {
      List<String> lines = new ArrayList<>();
      lines.add("# Hardcore Creative Access configuration");
      lines.add("# This file is shared by the current Fabric instance.");
      lines.add("# Authorization and player restore states are saved per world/server.");
      lines.add("");
      lines.add("# Automatically authorizes the integrated singleplayer/LAN owner.");
      lines.add("autoAuthorizeSingleplayerOwner=true");
      lines.add("");
      lines.add("# Restores creative mode on login when the player was previously enabled.");
      lines.add("autoRestoreCreativeOnLogin=true");
      lines.add("");
      lines.add("# Forces survival mode immediately when access is revoked or disabled.");
      lines.add("forceSurvivalOnRevoke=true");
      lines.add("");
      lines.add("# Master switch for allowing this mod to grant creative access in any world mode.");
      lines.add("allowCreativeAccess=true");
      lines.add("");
      lines.add("# Emits additional diagnostic logging when true.");
      lines.add("verboseLogging=false");
      lines.add("");
      lines.add("# Minimum vanilla operator level required to administrate the mod on a server. Range: 0-4");
      lines.add("adminPermissionLevel=2");
      lines.add("");
      lines.add("# Allows explicitly authorized non-operators to use admin commands exposed by this mod.");
      lines.add("defaultNonOpAccess=false");
      Files.write(path, lines, StandardCharsets.UTF_8);
   }
}
