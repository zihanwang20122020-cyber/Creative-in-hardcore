package dev.zihan.hardcorecreative.command;

import dev.zihan.hardcorecreative.ModConfig;
import dev.zihan.hardcorecreative.data.AuthorizedPlayersSavedData;
import dev.zihan.hardcorecreative.data.PlayerCreativeState;
import dev.zihan.hardcorecreative.inventory.ExtraInventoryContainer;
import dev.zihan.hardcorecreative.inventory.ExtraInventoryMenu;
import dev.zihan.hardcorecreative.inventory.ExtraInventorySavedData;
import dev.zihan.hardcorecreative.permission.PermissionNode;
import dev.zihan.hardcorecreative.permission.PermissionService;
import dev.zihan.hardcorecreative.util.ModeUtils;
import dev.zihan.hardcorecreative.util.PlayerLookup;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.Message;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestion;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import com.mojang.brigadier.tree.CommandNode;
import java.lang.reflect.Field;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.LevelBasedPermissionSet;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;

public final class HardcoreCreativeCommand {
   private static final Field COMMAND_REQUIREMENT_FIELD = resolveRequirementField();
   private static final SimpleCommandExceptionType PLAYER_REQUIRED = new SimpleCommandExceptionType(Component.literal("This command requires a player target."));
   private static final SimpleCommandExceptionType PLAYER_NOT_FOUND = new SimpleCommandExceptionType(Component.literal("Player not found in the server list or profile cache."));
   private static final SimpleCommandExceptionType COMMAND_BLOCKS_FORBIDDEN = new SimpleCommandExceptionType(Component.literal("Command blocks are not allowed to administer Hardcore Creative Access."));
   private static final SimpleCommandExceptionType NOT_AUTHORIZED_FOR_CREATIVE = new SimpleCommandExceptionType(Component.literal("Target player is not authorized for creative access in this world."));
   private static final SimpleCommandExceptionType FORBIDDEN_CREATIVE_COMMAND = new SimpleCommandExceptionType(Component.literal("This vanilla command is not allowed through Hardcore Creative Access."));
   private static final SimpleCommandExceptionType EMPTY_CREATIVE_COMMAND = new SimpleCommandExceptionType(Component.literal("You must provide a vanilla command to run."));
   private static final SimpleCommandExceptionType EXTRA_SLOTS_LOCKED = new SimpleCommandExceptionType(Component.literal("This player does not have the extra 30-slot inventory enabled."));
   private static final Set<String> ALLOWED_CREATIVE_COMMANDS = Set.of("gamemode", "give", "clear", "effect", "enchant", "experience", "xp", "item", "recipe", "teleport", "tp", "summon", "setblock", "fill", "clone", "particle", "time", "weather", "place", "loot", "locate", "playsound", "stopsound", "title", "tellraw", "kill", "damage", "attribute", "ride", "tag");
   private static final List<String> CREATIVE_COMMAND_EXAMPLES = List.of("give @s minecraft:command_block 1", "time set day", "weather clear", "tp @s ~ ~10 ~", "fill ~-5 ~-1 ~-5 ~5 ~3 ~5 minecraft:glass", "setblock ~ ~-1 ~ minecraft:command_block", "summon minecraft:villager ~ ~ ~");

   private HardcoreCreativeCommand() {
   }

   public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
      dispatcher.register(buildRoot("hardcorecreative"));
      dispatcher.register(buildRoot("hccreative"));
      patchAllowedVanillaCommandPermissions(dispatcher);
   }

   private static LiteralArgumentBuilder<CommandSourceStack> buildRoot(String literal) {
      return Commands.literal(literal)
         .requires(HardcoreCreativeCommand::canAccessRoot)
         .executes(context -> showHelp(context.getSource()))
         .then(Commands.literal("status")
            .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_SELF))
            .executes(context -> statusSelf(context.getSource()))
            .then(Commands.argument("player", StringArgumentType.word())
               .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_OTHERS))
               .suggests(HardcoreCreativeCommand::suggestPlayers)
               .executes(context -> statusOther(context.getSource(), StringArgumentType.getString(context, "player")))))
         .then(Commands.literal("grant")
            .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_OTHERS))
            .then(Commands.argument("player", StringArgumentType.word())
               .suggests(HardcoreCreativeCommand::suggestGrantCandidates)
               .executes(context -> grant(context.getSource(), StringArgumentType.getString(context, "player")))))
         .then(Commands.literal("revoke")
            .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_OTHERS))
            .then(Commands.argument("player", StringArgumentType.word())
               .suggests(HardcoreCreativeCommand::suggestAuthorizedPlayers)
               .executes(context -> revoke(context.getSource(), StringArgumentType.getString(context, "player")))))
         .then(Commands.literal("enable")
            .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_OTHERS))
            .then(Commands.argument("player", StringArgumentType.word())
               .suggests(HardcoreCreativeCommand::suggestPlayers)
               .executes(context -> enable(context.getSource(), StringArgumentType.getString(context, "player")))))
         .then(Commands.literal("disable")
            .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_OTHERS))
            .then(Commands.argument("player", StringArgumentType.word())
               .suggests(HardcoreCreativeCommand::suggestAuthorizedPlayers)
               .executes(context -> disable(context.getSource(), StringArgumentType.getString(context, "player")))))
         .then(Commands.literal("setmode")
            .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_SELF))
            .then(Commands.literal("creative")
               .executes(context -> setModeSelf(context.getSource(), true)))
            .then(Commands.literal("survival")
               .executes(context -> setModeSelf(context.getSource(), false)))
            .then(Commands.argument("player", StringArgumentType.word())
               .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_OTHERS))
               .suggests(HardcoreCreativeCommand::suggestPlayers)
               .then(Commands.literal("creative")
                  .executes(context -> setModeOther(context.getSource(), StringArgumentType.getString(context, "player"), true)))
               .then(Commands.literal("survival")
                  .executes(context -> setModeOther(context.getSource(), StringArgumentType.getString(context, "player"), false)))))
         .then(Commands.literal("list")
            .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_OTHERS))
            .executes(context -> listAuthorized(context.getSource())))
         .then(Commands.literal("extraslots")
            .executes(context -> openExtraSlots(context.getSource()))
            .then(Commands.literal("open")
               .executes(context -> openExtraSlots(context.getSource())))
            .then(Commands.literal("status")
               .executes(context -> extraSlotsStatusSelf(context.getSource()))
               .then(Commands.argument("player", StringArgumentType.word())
                  .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_OTHERS))
                  .suggests(HardcoreCreativeCommand::suggestPlayers)
                  .executes(context -> extraSlotsStatusOther(context.getSource(), StringArgumentType.getString(context, "player")))))
            .then(Commands.literal("add")
               .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_SELF))
               .executes(context -> addExtraSlotsSelf(context.getSource()))
               .then(Commands.argument("player", StringArgumentType.word())
                  .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_OTHERS))
                  .suggests(HardcoreCreativeCommand::suggestPlayers)
                  .executes(context -> addExtraSlots(context.getSource(), StringArgumentType.getString(context, "player")))))
            .then(Commands.literal("remove")
               .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_SELF))
               .executes(context -> removeExtraSlotsSelf(context.getSource()))
               .then(Commands.argument("player", StringArgumentType.word())
                  .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_OTHERS))
                  .suggests(HardcoreCreativeCommand::suggestPlayers)
                  .executes(context -> removeExtraSlots(context.getSource(), StringArgumentType.getString(context, "player"))))))
         .then(Commands.literal("creative")
            .requires(source -> PermissionService.get().has(source, PermissionNode.COMMAND_SELF))
            .executes(context -> listCreativeCommands(context.getSource()))
            .then(Commands.argument("command", StringArgumentType.greedyString())
               .suggests(HardcoreCreativeCommand::suggestCreativeCommands)
               .executes(context -> runCreativeCommand(context.getSource(), StringArgumentType.getString(context, "command")))))
         .then(Commands.literal("reload")
            .requires(source -> PermissionService.get().has(source, PermissionNode.ADMIN))
            .executes(context -> reload(context.getSource())))
         .then(Commands.literal("debug")
            .requires(source -> PermissionService.get().has(source, PermissionNode.ADMIN))
            .executes(context -> debug(context.getSource())));
   }

   private static boolean canAccessRoot(CommandSourceStack source) {
      PermissionService service = PermissionService.get();
      if (service.isCommandBlockSource(source)) {
         return false;
      } else {
         return service.isConsoleSource(source) || source.getEntity() instanceof ServerPlayer;
      }
   }

   @SuppressWarnings({"rawtypes", "unchecked"})
   private static void patchAllowedVanillaCommandPermissions(CommandDispatcher<CommandSourceStack> dispatcher) {
      for(String root : ALLOWED_CREATIVE_COMMANDS) {
         CommandNode<CommandSourceStack> node = dispatcher.getRoot().getChild(root);
         if (node != null) {
            Predicate<CommandSourceStack> originalRequirement = node.getRequirement();
            Predicate<CommandSourceStack> patchedRequirement = (source) -> originalRequirement.test(source) || canUseDirectCreativeCommand(source);

            try {
               COMMAND_REQUIREMENT_FIELD.set(node, patchedRequirement);
            } catch (IllegalAccessException exception) {
               throw new IllegalStateException("Failed to patch vanilla command permissions for " + root + ".", exception);
            }
         }
      }

   }

   private static boolean canUseDirectCreativeCommand(CommandSourceStack source) {
      PermissionService service = PermissionService.get();
      if (service.isCommandBlockSource(source)) {
         return false;
      } else {
         return service.isConsoleSource(source) ? true : service.has(source, PermissionNode.COMMAND_SELF);
      }
   }

   private static int statusSelf(CommandSourceStack source) throws CommandSyntaxException {
      ServerPlayer player = requirePlayerSource(source);
      return sendStatus(source, player.getGameProfile(), player);
   }

   private static int statusOther(CommandSourceStack source, String playerName) throws CommandSyntaxException {
      PlayerLookup.ResolvedPlayer target = resolve(source.getServer(), playerName);
      return sendStatus(source, target.profile(), target.onlinePlayer());
   }

   private static int grant(CommandSourceStack source, String playerName) throws CommandSyntaxException {
      rejectCommandBlock(source);
      PlayerLookup.ResolvedPlayer target = resolve(source.getServer(), playerName);
      PermissionService.get().grant(source.getServer(), target.profile());
      sendSuccess(source, "Granted creative authorization to " + target.profile().name() + ".");
      return 1;
   }

   private static int revoke(CommandSourceStack source, String playerName) throws CommandSyntaxException {
      rejectCommandBlock(source);
      PlayerLookup.ResolvedPlayer target = resolve(source.getServer(), playerName);
      PermissionService.get().revoke(source.getServer(), target.profile().id());
      if (target.onlinePlayer() != null && ModConfig.forceSurvivalOnRevoke()) {
         ModeUtils.applySurvival(target.onlinePlayer());
      }

      sendSuccess(source, "Revoked creative authorization from " + target.profile().name() + ".");
      return 1;
   }

   private static int enable(CommandSourceStack source, String playerName) throws CommandSyntaxException {
      rejectCommandBlock(source);
      PlayerLookup.ResolvedPlayer target = resolve(source.getServer(), playerName);
      PermissionService.get().enableCreative(source.getServer(), target.profile());
      if (target.onlinePlayer() != null) {
         ModeUtils.applyCreative(target.onlinePlayer());
      }

      sendSuccess(source, "Enabled creative mode for " + target.profile().name() + " in this world.");
      return 1;
   }

   private static int disable(CommandSourceStack source, String playerName) throws CommandSyntaxException {
      rejectCommandBlock(source);
      PlayerLookup.ResolvedPlayer target = resolve(source.getServer(), playerName);
      if (!PermissionService.get().isAuthorized(source.getServer(), target.profile().id())) {
         throw NOT_AUTHORIZED_FOR_CREATIVE.create();
      } else {
         PermissionService.get().disableCreative(source.getServer(), target.profile());
         if (target.onlinePlayer() != null && ModConfig.forceSurvivalOnRevoke()) {
            ModeUtils.applySurvival(target.onlinePlayer());
         }

         sendSuccess(source, "Disabled creative mode for " + target.profile().name() + " while keeping authorization.");
         return 1;
      }
   }

   private static int setModeSelf(CommandSourceStack source, boolean creative) throws CommandSyntaxException {
      rejectCommandBlock(source);
      ServerPlayer player = requirePlayerSource(source);
      return setMode(source, new PlayerLookup.ResolvedPlayer(player.getGameProfile(), player), creative);
   }

   private static int setModeOther(CommandSourceStack source, String playerName, boolean creative) throws CommandSyntaxException {
      rejectCommandBlock(source);
      return setMode(source, resolve(source.getServer(), playerName), creative);
   }

   private static int setMode(CommandSourceStack source, PlayerLookup.ResolvedPlayer target, boolean creative) throws CommandSyntaxException {
      if (creative && !PermissionService.get().isAuthorized(source.getServer(), target.profile().id())) {
         throw NOT_AUTHORIZED_FOR_CREATIVE.create();
      } else {
         if (creative) {
            PermissionService.get().enableCreative(source.getServer(), target.profile());
            if (target.onlinePlayer() != null) {
               ModeUtils.applyCreative(target.onlinePlayer());
            }
         } else {
            PermissionService.get().disableCreative(source.getServer(), target.profile());
            if (target.onlinePlayer() != null) {
               ModeUtils.applySurvival(target.onlinePlayer());
            }
         }

         sendSuccess(source, "Set " + target.profile().name() + " to " + (creative ? "creative" : "survival") + ".");
         return 1;
      }
   }

   private static CompletableFuture<Suggestions> suggestPlayers(CommandContext<CommandSourceStack> context, SuggestionsBuilder builder) {
      return SharedSuggestionProvider.suggest(knownPlayerNames(((CommandSourceStack)context.getSource()).getServer()), builder);
   }

   private static CompletableFuture<Suggestions> suggestAuthorizedPlayers(CommandContext<CommandSourceStack> context, SuggestionsBuilder builder) {
      return SharedSuggestionProvider.suggest(authorizedPlayerNames(((CommandSourceStack)context.getSource()).getServer()), builder);
   }

   private static CompletableFuture<Suggestions> suggestGrantCandidates(CommandContext<CommandSourceStack> context, SuggestionsBuilder builder) {
      TreeSet<String> suggestions = knownPlayerNames(((CommandSourceStack)context.getSource()).getServer());
      suggestions.removeAll(authorizedPlayerNames(((CommandSourceStack)context.getSource()).getServer()));
      return SharedSuggestionProvider.suggest(suggestions, builder);
   }

   private static CompletableFuture<Suggestions> suggestCreativeCommands(CommandContext<CommandSourceStack> context, SuggestionsBuilder builder) {
      String raw = normalizeForwardedCommand(builder.getRemaining());
      if (raw.isBlank()) {
         TreeSet<String> suggestions = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
         suggestions.addAll(ALLOWED_CREATIVE_COMMANDS);
         suggestions.addAll(CREATIVE_COMMAND_EXAMPLES);
         return SharedSuggestionProvider.suggest(suggestions, builder);
      } else if (!raw.contains(" ")) {
         TreeSet<String> suggestions = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
         suggestions.addAll(ALLOWED_CREATIVE_COMMANDS);
         CREATIVE_COMMAND_EXAMPLES.stream()
            .filter(example -> example.regionMatches(true, 0, raw, 0, raw.length()))
            .forEach(suggestions::add);
         return SharedSuggestionProvider.suggest(suggestions, builder);
      } else {
         String root = commandRoot(raw);
         if (!ALLOWED_CREATIVE_COMMANDS.contains(root)) {
            return Suggestions.empty();
         } else {
            CommandSourceStack elevatedSource = ((CommandSourceStack)context.getSource()).withMaximumPermission(LevelBasedPermissionSet.OWNER);
            CommandDispatcher<CommandSourceStack> dispatcher = ((CommandSourceStack)context.getSource()).getServer().getCommands().getDispatcher();
            ParseResults<CommandSourceStack> parse = dispatcher.parse(raw, elevatedSource);
            return dispatcher.getCompletionSuggestions(parse).thenApply((suggestionsx) -> rebaseSuggestions(builder, suggestionsx));
         }
      }
   }

   private static int listAuthorized(CommandSourceStack source) {
      List<AuthorizedPlayersSavedData.AuthorizedEntry> entries = AuthorizedPlayersSavedData.get(source.getServer()).entries();
      if (entries.isEmpty()) {
         sendSuccess(source, "No players are currently authorized.");
         return 1;
      } else {
         String joined = entries.stream()
            .map(entry -> entry.name() + " (" + entry.uuid() + ")")
            .collect(Collectors.joining(", "));
         sendSuccess(source, "Authorized players: " + joined);
         return 1;
      }
   }

   private static int showHelp(CommandSourceStack source) {
      sendSuccess(source, "Hardcore Creative Access commands:");
      sendSuccess(source, " - /hardcorecreative status [player]");
      sendSuccess(source, " - /hardcorecreative grant <player>");
      sendSuccess(source, " - /hardcorecreative enable <player>");
      sendSuccess(source, " - /hardcorecreative setmode <creative|survival>");
      sendSuccess(source, " - /hardcorecreative extraslots add [player]");
      sendSuccess(source, " - /hardcorecreative extraslots open");
      sendSuccess(source, " - /hardcorecreative creative <vanilla command...>");
      return 1;
   }

   private static int openExtraSlots(CommandSourceStack source) throws CommandSyntaxException {
      rejectCommandBlock(source);
      ServerPlayer player = requirePlayerSource(source);
      ExtraInventorySavedData data = ExtraInventorySavedData.get(source.getServer());
      if (!data.isUnlocked(player.getUUID())) {
         throw EXTRA_SLOTS_LOCKED.create();
      } else {
         data.rememberName(player.getUUID(), player.getGameProfile().name());
         player.openMenu(new SimpleMenuProvider((containerId, inventory, ignored) -> new ExtraInventoryMenu(containerId, inventory, new ExtraInventoryContainer(source.getServer(), player.getUUID(), player.getGameProfile().name())), Component.literal("Extra inventory (+30 slots)")));
         return 1;
      }
   }

   private static int extraSlotsStatusSelf(CommandSourceStack source) throws CommandSyntaxException {
      ServerPlayer player = requirePlayerSource(source);
      return sendExtraSlotsStatus(source, player.getGameProfile(), player);
   }

   private static int extraSlotsStatusOther(CommandSourceStack source, String playerName) throws CommandSyntaxException {
      return sendExtraSlotsStatus(source, resolve(source.getServer(), playerName).profile(), (ServerPlayer)null);
   }

   private static int addExtraSlots(CommandSourceStack source, String playerName) throws CommandSyntaxException {
      rejectCommandBlock(source);
      PlayerLookup.ResolvedPlayer target = resolve(source.getServer(), playerName);
      ExtraInventorySavedData data = ExtraInventorySavedData.get(source.getServer());
      data.unlock(target.profile().id(), target.profile().name());
      sendSuccess(source, "Enabled the extra 30-slot inventory for " + target.profile().name() + ".");
      return 1;
   }

   private static int addExtraSlotsSelf(CommandSourceStack source) throws CommandSyntaxException {
      ServerPlayer player = requirePlayerSource(source);
      ExtraInventorySavedData data = ExtraInventorySavedData.get(source.getServer());
      data.unlock(player.getUUID(), player.getGameProfile().name());
      sendSuccess(source, "Enabled your extra 30-slot inventory.");
      return 1;
   }

   private static int removeExtraSlots(CommandSourceStack source, String playerName) throws CommandSyntaxException {
      rejectCommandBlock(source);
      PlayerLookup.ResolvedPlayer target = resolve(source.getServer(), playerName);
      ExtraInventorySavedData data = ExtraInventorySavedData.get(source.getServer());
      data.lock(target.profile().id(), target.profile().name());
      if (target.onlinePlayer() != null) {
         target.onlinePlayer().closeContainer();
      }

      sendSuccess(source, "Disabled the extra 30-slot inventory for " + target.profile().name() + ". Stored contents were kept.");
      return 1;
   }

   private static int removeExtraSlotsSelf(CommandSourceStack source) throws CommandSyntaxException {
      ServerPlayer player = requirePlayerSource(source);
      ExtraInventorySavedData data = ExtraInventorySavedData.get(source.getServer());
      data.lock(player.getUUID(), player.getGameProfile().name());
      player.closeContainer();
      sendSuccess(source, "Disabled your extra 30-slot inventory. Stored contents were kept.");
      return 1;
   }

   private static int listCreativeCommands(CommandSourceStack source) {
      String joined = (String)ALLOWED_CREATIVE_COMMANDS.stream().sorted(String.CASE_INSENSITIVE_ORDER).collect(Collectors.joining(", "));
      sendSuccess(source, "Allowed creative command roots: " + joined);
      sendSuccess(source, "Use /hardcorecreative creative <vanilla command...> to run one of them with temporary elevated command access.");
      sendSuccess(source, "Examples: /hardcorecreative creative give @s minecraft:command_block 1 | /hardcorecreative creative time set day | /hardcorecreative creative fill ~-5 ~-1 ~-5 ~5 ~3 ~5 minecraft:glass");
      return 1;
   }

   private static int runCreativeCommand(CommandSourceStack source, String rawCommand) throws CommandSyntaxException {
      rejectCommandBlock(source);
      String command = normalizeForwardedCommand(rawCommand);
      if (command.isBlank()) {
         throw EMPTY_CREATIVE_COMMAND.create();
      } else {
         String root = commandRoot(command);
         if (!ALLOWED_CREATIVE_COMMANDS.contains(root)) {
            throw FORBIDDEN_CREATIVE_COMMAND.create();
         } else {
            CommandSourceStack elevatedSource = source.withMaximumPermission(LevelBasedPermissionSet.OWNER);
            source.getServer().getCommands().performPrefixedCommand(elevatedSource, command);
            return 1;
         }
      }
   }

   private static int reload(CommandSourceStack source) throws CommandSyntaxException {
      rejectCommandBlock(source);
      ModConfig.reload(source.getServer());
      PermissionService.get().reapplyAll(source.getServer());
      sendSuccess(source, "Hardcore Creative Access config reloaded.");
      return 1;
   }

   private static int debug(CommandSourceStack source) {
      MinecraftServer server = source.getServer();
      AuthorizedPlayersSavedData authorized = AuthorizedPlayersSavedData.get(server);
      sendSuccess(source, "Hardcore world=" + ModeUtils.isHardcoreServer(server) + ", allowCreativeAccess=" + ModConfig.allowCreativeAccess() + ", authorizedCount=" + authorized.entries().size() + ", autoAuthorizeSingleplayerOwner=" + ModConfig.autoAuthorizeSingleplayerOwner() + ", autoRestoreCreativeOnLogin=" + ModConfig.autoRestoreCreativeOnLogin() + ", forceSurvivalOnRevoke=" + ModConfig.forceSurvivalOnRevoke() + ", adminPermissionLevel=" + ModConfig.adminPermissionLevel() + ", defaultNonOpAccess=" + ModConfig.defaultNonOpAccess());
      return 1;
   }

   private static int sendStatus(CommandSourceStack source, GameProfile profile, ServerPlayer onlinePlayer) {
      MinecraftServer server = source.getServer();
      PermissionService permissionService = PermissionService.get();
      AuthorizedPlayersSavedData authorizedData = AuthorizedPlayersSavedData.get(server);
      PlayerCreativeState stateData = PlayerCreativeState.get(server);
      UUID uuid = profile.id();
      Optional<PlayerCreativeState.StateRecord> state = stateData.get(uuid);
      sendSuccess(source, "Status for " + profile.name() + ":");
      sendSuccess(source, " - Authorized: " + authorizedData.isAuthorized(uuid));
      sendSuccess(source, " - Online: " + (onlinePlayer != null));
      String currentMode = onlinePlayer != null ? ModeUtils.modeName(onlinePlayer) : "offline";
      sendSuccess(source, " - Current mode: " + currentMode);
      Optional<Boolean> creativeRequested = state.map(PlayerCreativeState.StateRecord::creativeRequested);
      sendSuccess(source, " - Creative requested: " + creativeRequested.orElse(false));
      Optional<Boolean> autoRestore = state.map(PlayerCreativeState.StateRecord::autoRestore);
      sendSuccess(source, " - Auto restore: " + autoRestore.orElse(false));
      if (onlinePlayer != null) {
         for(PermissionNode node : PermissionNode.values()) {
            sendSuccess(source, " - " + permissionService.describeNode(onlinePlayer, node));
         }
      }

      return 1;
   }

   private static int sendExtraSlotsStatus(CommandSourceStack source, GameProfile profile, ServerPlayer ignoredOnlinePlayer) {
      ExtraInventorySavedData data = ExtraInventorySavedData.get(source.getServer());
      List<ItemStack> items = data.loadItems(profile.id(), profile.name());
      long usedSlots = items.stream().filter((stack) -> !stack.isEmpty()).count();
      sendSuccess(source, "Extra inventory status for " + profile.name() + ":");
      sendSuccess(source, " - Enabled: " + data.isUnlocked(profile.id()));
      sendSuccess(source, " - Capacity: 30 usable slots");
      sendSuccess(source, " - Filled slots: " + usedSlots);
      return 1;
   }

   private static PlayerLookup.ResolvedPlayer resolve(MinecraftServer server, String playerName) throws CommandSyntaxException {
      return PlayerLookup.resolve(server, playerName).orElseThrow(PLAYER_NOT_FOUND::create);
   }

   private static ServerPlayer requirePlayerSource(CommandSourceStack source) throws CommandSyntaxException {
      Entity entity = source.getEntity();
      if (entity instanceof ServerPlayer player) {
         return player;
      } else {
         throw PLAYER_REQUIRED.create();
      }
   }

   private static void rejectCommandBlock(CommandSourceStack source) throws CommandSyntaxException {
      if (PermissionService.get().isCommandBlockSource(source)) {
         throw COMMAND_BLOCKS_FORBIDDEN.create();
      }
   }

   private static void sendSuccess(CommandSourceStack source, String message) {
      source.sendSuccess(() -> Component.literal(message), false);
   }

   private static Suggestions rebaseSuggestions(SuggestionsBuilder builder, Suggestions suggestions) {
      SuggestionsBuilder rebased = builder.createOffset(builder.getStart() + suggestions.getRange().getStart());

      for(Suggestion suggestion : suggestions.getList()) {
         Message tooltip = suggestion.getTooltip();
         if (tooltip != null) {
            rebased.suggest(suggestion.getText(), tooltip);
         } else {
            rebased.suggest(suggestion.getText());
         }
      }

      return rebased.build();
   }

   private static String normalizeForwardedCommand(String rawCommand) {
      String trimmed = rawCommand == null ? "" : rawCommand.trim();
      return trimmed.startsWith("/") ? trimmed.substring(1).trim() : trimmed;
   }

   private static String commandRoot(String command) {
      int separator = command.indexOf(32);
      String root = separator >= 0 ? command.substring(0, separator) : command;
      return root.toLowerCase();
   }

   private static TreeSet<String> knownPlayerNames(MinecraftServer server) {
      TreeSet<String> suggestions = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
      Collections.addAll(suggestions, server.getPlayerList().getPlayerNamesArray());
      suggestions.addAll(authorizedPlayerNames(server));
      return suggestions;
   }

   private static TreeSet<String> authorizedPlayerNames(MinecraftServer server) {
      TreeSet<String> suggestions = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
      AuthorizedPlayersSavedData.get(server).entries().stream()
         .map(AuthorizedPlayersSavedData.AuthorizedEntry::name)
         .filter(name -> !name.isBlank())
         .forEach(suggestions::add);
      return suggestions;
   }

   private static Field resolveRequirementField() {
      try {
         Field field = CommandNode.class.getDeclaredField("requirement");
         field.setAccessible(true);
         return field;
      } catch (ReflectiveOperationException exception) {
         throw new ExceptionInInitializerError(exception);
      }
   }
}
