package dev.zihan.hardcorecreative.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

public final class AuthorizedPlayersSavedData extends SavedData {
    private static final Codec<StoredEntry> ENTRY_CODEC = RecordCodecBuilder.create(instance -> instance.group(
            UUIDUtil.STRING_CODEC.fieldOf("uuid").forGetter(StoredEntry::uuid),
            Codec.STRING.optionalFieldOf("name", "").forGetter(StoredEntry::name)
    ).apply(instance, StoredEntry::new));

    private static final Codec<AuthorizedPlayersSavedData> CODEC = ENTRY_CODEC.listOf()
            .optionalFieldOf("entries", List.of())
            .codec()
            .xmap(AuthorizedPlayersSavedData::fromStoredEntries, AuthorizedPlayersSavedData::toStoredEntries);

    private static final SavedDataType<AuthorizedPlayersSavedData> TYPE = new SavedDataType<>(
            Identifier.fromNamespaceAndPath("hardcorecreative", "authorized_players"),
            AuthorizedPlayersSavedData::new,
            CODEC,
            null
    );

    private final Set<UUID> authorizedPlayers = new HashSet<>();
    private final Map<UUID, String> knownNames = new HashMap<>();

    public static AuthorizedPlayersSavedData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(TYPE);
    }

    private static AuthorizedPlayersSavedData fromStoredEntries(List<StoredEntry> storedEntries) {
        AuthorizedPlayersSavedData data = new AuthorizedPlayersSavedData();
        for (StoredEntry entry : storedEntries) {
            data.authorizedPlayers.add(entry.uuid());
            if (!entry.name().isBlank()) {
                data.knownNames.put(entry.uuid(), entry.name());
            }
        }
        return data;
    }

    private List<StoredEntry> toStoredEntries() {
        List<StoredEntry> entries = new ArrayList<>();
        for (UUID uuid : authorizedPlayers.stream().sorted(Comparator.comparing(UUID::toString)).toList()) {
            entries.add(new StoredEntry(uuid, knownNames.getOrDefault(uuid, "")));
        }
        return entries;
    }

    public boolean isAuthorized(UUID uuid) {
        return authorizedPlayers.contains(uuid);
    }

    public void authorize(UUID uuid, String lastKnownName) {
        boolean changed = authorizedPlayers.add(uuid);
        if (rememberNameInternal(uuid, lastKnownName) || changed) {
            setDirty();
        }
    }

    public void revoke(UUID uuid) {
        boolean removed = authorizedPlayers.remove(uuid);
        boolean nameRemoved = knownNames.remove(uuid) != null;
        if (removed || nameRemoved) {
            setDirty();
        }
    }

    public void rememberName(UUID uuid, String lastKnownName) {
        if (rememberNameInternal(uuid, lastKnownName)) {
            setDirty();
        }
    }

    public String getKnownName(UUID uuid) {
        return knownNames.getOrDefault(uuid, uuid.toString());
    }

    public List<AuthorizedEntry> entries() {
        List<AuthorizedEntry> entries = new ArrayList<>();
        for (UUID uuid : authorizedPlayers) {
            entries.add(new AuthorizedEntry(uuid, getKnownName(uuid)));
        }
        entries.sort(Comparator.comparing(AuthorizedEntry::name, String.CASE_INSENSITIVE_ORDER));
        return entries;
    }

    private boolean rememberNameInternal(UUID uuid, String lastKnownName) {
        if (lastKnownName == null || lastKnownName.isBlank()) {
            return false;
        }
        String previous = knownNames.put(uuid, lastKnownName);
        return !lastKnownName.equals(previous);
    }

    public record AuthorizedEntry(UUID uuid, String name) {
    }

    private record StoredEntry(UUID uuid, String name) {
    }
}
