package dev.zihan.hardcorecreative.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

public final class PlayerCreativeState extends SavedData {
    private static final Codec<StoredState> STORED_STATE_CODEC = RecordCodecBuilder.create(instance -> instance.group(
            UUIDUtil.STRING_CODEC.fieldOf("uuid").forGetter(StoredState::uuid),
            Codec.BOOL.optionalFieldOf("creativeRequested", false).forGetter(StoredState::creativeRequested),
            Codec.BOOL.optionalFieldOf("autoRestore", true).forGetter(StoredState::autoRestore),
            Codec.STRING.optionalFieldOf("lastKnownName", "").forGetter(StoredState::lastKnownName)
    ).apply(instance, StoredState::new));

    private static final Codec<PlayerCreativeState> CODEC = STORED_STATE_CODEC.listOf()
            .optionalFieldOf("players", List.of())
            .codec()
            .xmap(PlayerCreativeState::fromStoredStates, PlayerCreativeState::toStoredStates);

    private static final SavedDataType<PlayerCreativeState> TYPE = new SavedDataType<>(
            Identifier.fromNamespaceAndPath("hardcorecreative", "player_state"),
            PlayerCreativeState::new,
            CODEC,
            null
    );

    private final Map<UUID, StateRecord> states = new HashMap<>();

    public static PlayerCreativeState get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(TYPE);
    }

    private static PlayerCreativeState fromStoredStates(List<StoredState> storedStates) {
        PlayerCreativeState data = new PlayerCreativeState();
        for (StoredState state : storedStates) {
            data.states.put(state.uuid(), new StateRecord(
                    state.creativeRequested(),
                    state.autoRestore(),
                    state.lastKnownName()
            ));
        }
        return data;
    }

    private List<StoredState> toStoredStates() {
        List<StoredState> players = new ArrayList<>(states.size());
        for (Map.Entry<UUID, StateRecord> entry : states.entrySet()) {
            StateRecord state = entry.getValue();
            players.add(new StoredState(
                    entry.getKey(),
                    state.creativeRequested(),
                    state.autoRestore(),
                    state.lastKnownName()
            ));
        }
        return players;
    }

    public Optional<StateRecord> get(UUID uuid) {
        return Optional.ofNullable(states.get(uuid));
    }

    public void rememberName(UUID uuid, String name) {
        if (name == null || name.isBlank()) {
            return;
        }

        StateRecord existing = states.get(uuid);
        if (existing != null && !name.equals(existing.lastKnownName())) {
            states.put(uuid, existing.withLastKnownName(name));
            setDirty();
        }
    }

    public void markEnabled(UUID uuid, String name) {
        updateIfChanged(uuid, new StateRecord(true, true, normalizeName(name)));
    }

    public void markDisabled(UUID uuid, String name) {
        updateIfChanged(uuid, new StateRecord(false, false, normalizeName(name)));
    }

    public void ensureExists(UUID uuid, String name) {
        if (!states.containsKey(uuid)) {
            states.put(uuid, new StateRecord(false, true, normalizeName(name)));
            setDirty();
        }
    }

    public void remove(UUID uuid) {
        if (states.remove(uuid) != null) {
            setDirty();
        }
    }

    private static String normalizeName(String name) {
        return name == null ? "" : name;
    }

    private void updateIfChanged(UUID uuid, StateRecord newState) {
        StateRecord previous = states.put(uuid, newState);
        if (!newState.equals(previous)) {
            setDirty();
        }
    }

    public record StateRecord(boolean creativeRequested, boolean autoRestore, String lastKnownName) {
        public StateRecord withLastKnownName(String name) {
            return new StateRecord(creativeRequested, autoRestore, name);
        }
    }

    private record StoredState(UUID uuid, boolean creativeRequested, boolean autoRestore, String lastKnownName) {
    }
}
