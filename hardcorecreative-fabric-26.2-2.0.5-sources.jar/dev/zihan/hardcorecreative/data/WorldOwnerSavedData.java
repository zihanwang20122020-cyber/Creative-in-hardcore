package dev.zihan.hardcorecreative.data;

import com.mojang.authlib.GameProfile;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

public final class WorldOwnerSavedData extends SavedData {
   private static final Codec<WorldOwnerSavedData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
         UUIDUtil.STRING_CODEC.optionalFieldOf("ownerUuid").forGetter(WorldOwnerSavedData::ownerUuid),
         Codec.STRING.optionalFieldOf("ownerName", "").forGetter(WorldOwnerSavedData::ownerName),
         Codec.BOOL.optionalFieldOf("legacyAuthorizationMigrated", false)
               .forGetter(WorldOwnerSavedData::legacyAuthorizationMigrated)
   ).apply(instance, WorldOwnerSavedData::new));
   private static final SavedDataType<WorldOwnerSavedData> TYPE = new SavedDataType<>(
         Identifier.fromNamespaceAndPath("hardcorecreative", "world_owner"),
         WorldOwnerSavedData::new,
         CODEC,
         null
   );
   private UUID ownerUuid;
   private String ownerName;
   private boolean legacyAuthorizationMigrated;

   public WorldOwnerSavedData() {
      this(Optional.empty(), "", false);
   }

   private WorldOwnerSavedData(Optional<UUID> ownerUuid, String ownerName, boolean legacyAuthorizationMigrated) {
      this.ownerUuid = ownerUuid.orElse(null);
      this.ownerName = ownerName == null ? "" : ownerName;
      this.legacyAuthorizationMigrated = legacyAuthorizationMigrated;
   }

   public static WorldOwnerSavedData get(MinecraftServer server) {
      return server.overworld().getDataStorage().computeIfAbsent(TYPE);
   }

   public boolean hasOwner() {
      return this.ownerUuid != null;
   }

   public boolean isOwner(UUID playerUuid) {
      return this.ownerUuid != null && this.ownerUuid.equals(playerUuid);
   }

   public Optional<UUID> ownerUuid() {
      return Optional.ofNullable(this.ownerUuid);
   }

   public String ownerName() {
      return this.ownerName;
   }

   public boolean legacyAuthorizationMigrated() {
      return this.legacyAuthorizationMigrated;
   }

   public void setOwner(GameProfile profile) {
      UUID newOwnerUuid = profile.id();
      String newOwnerName = normalizeName(profile.name());
      if (!newOwnerUuid.equals(this.ownerUuid) || !newOwnerName.equals(this.ownerName)) {
         this.ownerUuid = newOwnerUuid;
         this.ownerName = newOwnerName;
         this.setDirty();
      }

   }

   public void markLegacyAuthorizationMigrated() {
      if (!this.legacyAuthorizationMigrated) {
         this.legacyAuthorizationMigrated = true;
         this.setDirty();
      }

   }

   private static String normalizeName(String name) {
      return name == null ? "" : name;
   }
}
