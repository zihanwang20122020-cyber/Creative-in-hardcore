package dev.zihan.hardcorecreative.event;

import dev.zihan.hardcorecreative.permission.PermissionService;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.level.ServerPlayer;

public final class PlayerEventHandler {
   private PlayerEventHandler() {
   }

   public static void register() {
      ServerPlayConnectionEvents.JOIN.register((ServerPlayConnectionEvents.Join)(handler, sender, server) -> PermissionService.get().onPlayerLogin(handler.player));
      ServerPlayConnectionEvents.DISCONNECT.register((ServerPlayConnectionEvents.Disconnect)(handler, server) -> PermissionService.get().onPlayerLogout(handler.player));
      ServerPlayerEvents.AFTER_RESPAWN.register((ServerPlayerEvents.AfterRespawn)(oldPlayer, newPlayer, alive) -> PermissionService.get().onPlayerClone(oldPlayer, newPlayer));
      ServerTickEvents.END_SERVER_TICK.register((ServerTickEvents.EndTick)(server) -> {
         for(ServerPlayer player : server.getPlayerList().getPlayers()) {
            PermissionService.get().onPlayerTick(player);
         }

      });
   }
}
