package dev.zihan.hardcorecreative.inventory;

import java.util.List;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class ExtraInventoryContainer extends SimpleContainer {
   public static final int USABLE_SLOTS = 30;
   public static final int DISPLAY_SLOTS = 36;
   public static final int LOCKED_SLOT_COUNT = 6;
   private static final ItemStack LOCKED_SLOT_MARKER;
   private final MinecraftServer server;
   private final UUID playerId;
   private final String playerName;

   public ExtraInventoryContainer(MinecraftServer server, UUID playerId, String playerName) {
      super(36);
      this.server = server;
      this.playerId = playerId;
      this.playerName = playerName;
      List<ItemStack> savedItems = ExtraInventorySavedData.get(server).loadItems(playerId, playerName);

      for(int slot = 0; slot < 30; ++slot) {
         this.getItems().set(slot, ((ItemStack)savedItems.get(slot)).copy());
      }

      this.refreshLockedSlots();
   }

   public void setChanged() {
      this.refreshLockedSlots();
      this.saveToData();
      super.setChanged();
   }

   public ItemStack removeItem(int slot, int amount) {
      return isLockedSlot(slot) ? ItemStack.EMPTY : super.removeItem(slot, amount);
   }

   public ItemStack removeItemNoUpdate(int slot) {
      return isLockedSlot(slot) ? ItemStack.EMPTY : super.removeItemNoUpdate(slot);
   }

   public void setItem(int slot, ItemStack stack) {
      if (isLockedSlot(slot)) {
         this.refreshLockedSlots();
      } else {
         super.setItem(slot, stack);
      }
   }

   public void clearContent() {
      for(int slot = 0; slot < 30; ++slot) {
         this.getItems().set(slot, ItemStack.EMPTY);
      }

      this.refreshLockedSlots();
      this.saveToData();
   }

   public void saveToData() {
      ExtraInventorySavedData.get(this.server).saveItems(this.playerId, this.playerName, this.getItems().subList(0, 30));
   }

   private void refreshLockedSlots() {
      for(int slot = 30; slot < 36; ++slot) {
         this.getItems().set(slot, LOCKED_SLOT_MARKER.copy());
      }

   }

   private static boolean isLockedSlot(int slot) {
      return slot >= 30 && slot < 36;
   }

   static {
      LOCKED_SLOT_MARKER = new ItemStack(Items.BARRIER);
   }
}
