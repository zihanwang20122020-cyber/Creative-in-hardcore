package dev.zihan.hardcorecreative.inventory;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;

public final class ExtraInventoryMenu extends ChestMenu {
   public ExtraInventoryMenu(int syncId, Inventory inventory, ExtraInventoryContainer container) {
      super(MenuType.GENERIC_9x4, syncId, inventory, container, 4);

      for(int slot = 30; slot < 36; ++slot) {
         Slot original = (Slot)this.slots.get(slot);
         this.slots.set(slot, new LockedExtraInventorySlot(container, slot, original.x, original.y));
      }

   }

   public void removed(Player player) {
      super.removed(player);
      Container container = this.getContainer();
      if (container instanceof ExtraInventoryContainer extraInventoryContainer) {
         extraInventoryContainer.saveToData();
      }

   }
}
