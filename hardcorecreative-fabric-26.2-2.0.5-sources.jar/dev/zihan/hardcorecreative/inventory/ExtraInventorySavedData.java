package dev.zihan.hardcorecreative.inventory;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

public final class ExtraInventorySavedData extends SavedData {
   private static final Codec<List<ItemStack>> ITEMS_CODEC = ItemStack.OPTIONAL_CODEC.listOf()
         .xmap(ExtraInventorySavedData::normalizeItems, ExtraInventorySavedData::copyItems);
   private static final Codec<StoredEntry> ENTRY_CODEC = RecordCodecBuilder.create(instance -> instance.group(
         UUIDUtil.STRING_CODEC.fieldOf("uuid").forGetter(StoredEntry::uuid),
         Codec.STRING.optionalFieldOf("name", "").forGetter(StoredEntry::name),
         Codec.BOOL.optionalFieldOf("unlocked", false).forGetter(StoredEntry::unlocked),
         ITEMS_CODEC.optionalFieldOf("items", List.of()).forGetter(StoredEntry::items)
   ).apply(instance, StoredEntry::new));
   private static final Codec<ExtraInventorySavedData> CODEC = ENTRY_CODEC.listOf()
         .optionalFieldOf("entries", List.of())
         .codec()
         .xmap(ExtraInventorySavedData::fromStoredEntries, ExtraInventorySavedData::toStoredEntries);
   private static final SavedDataType<ExtraInventorySavedData> TYPE = new SavedDataType<>(
         Identifier.fromNamespaceAndPath("hardcorecreative", "extra_inventory"),
         ExtraInventorySavedData::new,
         CODEC,
         null
   );
   private final Map<UUID, ExtraInventoryRecord> records = new HashMap<>();

   public static ExtraInventorySavedData get(MinecraftServer server) {
      return server.overworld().getDataStorage().computeIfAbsent(TYPE);
   }

   public boolean isUnlocked(UUID playerId) {
      return this.records.getOrDefault(playerId, ExtraInventorySavedData.ExtraInventoryRecord.empty()).unlocked();
   }

   public void unlock(UUID playerId, String playerName) {
      ExtraInventoryRecord current = this.records.getOrDefault(playerId, ExtraInventorySavedData.ExtraInventoryRecord.empty());
      ExtraInventoryRecord updated = current.withName(playerName).withUnlocked(true);
      if (!updated.equals(current)) {
         this.records.put(playerId, updated);
         this.setDirty();
      }

   }

   public void lock(UUID playerId, String playerName) {
      ExtraInventoryRecord current = this.records.getOrDefault(playerId, ExtraInventorySavedData.ExtraInventoryRecord.empty());
      ExtraInventoryRecord updated = current.withName(playerName).withUnlocked(false);
      if (!updated.equals(current)) {
         this.records.put(playerId, updated);
         this.setDirty();
      }

   }

   public void rememberName(UUID playerId, String playerName) {
      ExtraInventoryRecord current = this.records.get(playerId);
      if (current != null) {
         ExtraInventoryRecord updated = current.withName(playerName);
         if (!updated.equals(current)) {
            this.records.put(playerId, updated);
            this.setDirty();
         }

      }
   }

   public List<ItemStack> loadItems(UUID playerId, String playerName) {
      ExtraInventoryRecord current = this.records.getOrDefault(playerId, ExtraInventorySavedData.ExtraInventoryRecord.empty()).withName(playerName);
      if (!current.equals(this.records.get(playerId))) {
         this.records.put(playerId, current);
         this.setDirty();
      }

      return copyItems(current.items());
   }

   public void saveItems(UUID playerId, String playerName, List<ItemStack> items) {
      ExtraInventoryRecord current = this.records.getOrDefault(playerId, ExtraInventorySavedData.ExtraInventoryRecord.empty());
      ExtraInventoryRecord updated = new ExtraInventoryRecord(normalizeName(playerName, current.name()), current.unlocked(), normalizeItems(items));
      if (!updated.equals(current)) {
         this.records.put(playerId, updated);
         this.setDirty();
      }

   }

   public String getKnownName(UUID playerId) {
      return this.records.getOrDefault(playerId, ExtraInventorySavedData.ExtraInventoryRecord.empty()).nameOrUuid(playerId);
   }

   private static ExtraInventorySavedData fromStoredEntries(List<StoredEntry> storedEntries) {
      ExtraInventorySavedData data = new ExtraInventorySavedData();

      for(StoredEntry entry : storedEntries) {
         data.records.put(entry.uuid(), new ExtraInventoryRecord(normalizeName(entry.name(), ""), entry.unlocked(), normalizeItems(entry.items())));
      }

      return data;
   }

   private List<StoredEntry> toStoredEntries() {
      List<StoredEntry> entries = new ArrayList<>();
      this.records.entrySet().stream()
            .sorted(Map.Entry.comparingByKey(Comparator.comparing(UUID::toString)))
            .forEach(entry -> {
               ExtraInventoryRecord record = entry.getValue();
               entries.add(new StoredEntry(entry.getKey(), record.name(), record.unlocked(), copyItems(record.items())));
            });
      return entries;
   }

   private static List<ItemStack> normalizeItems(List<ItemStack> items) {
      List<ItemStack> normalized = new ArrayList<>(30);
      if (items != null) {
         for(int index = 0; index < Math.min(items.size(), 30); ++index) {
            ItemStack stack = items.get(index);
            normalized.add(stack == null ? ItemStack.EMPTY : stack.copy());
         }
      }

      while(normalized.size() < 30) {
         normalized.add(ItemStack.EMPTY);
      }

      return normalized;
   }

   private static List<ItemStack> copyItems(List<ItemStack> items) {
      List<ItemStack> copies = new ArrayList<>(items.size());

      for(ItemStack stack : items) {
         copies.add(stack == null ? ItemStack.EMPTY : stack.copy());
      }

      return copies;
   }

   private static String normalizeName(String candidate, String fallback) {
      if (candidate != null && !candidate.isBlank()) {
         return candidate;
      } else {
         return fallback == null ? "" : fallback;
      }
   }
   private static record StoredEntry(UUID uuid, String name, boolean unlocked, List<ItemStack> items) {
   }

   private static record ExtraInventoryRecord(String name, boolean unlocked, List<ItemStack> items) {
      private static ExtraInventoryRecord empty() {
         return new ExtraInventoryRecord("", false, ExtraInventorySavedData.normalizeItems(List.of()));
      }

      private ExtraInventoryRecord withName(String playerName) {
         return new ExtraInventoryRecord(ExtraInventorySavedData.normalizeName(playerName, this.name), this.unlocked, ExtraInventorySavedData.copyItems(this.items));
      }

      private ExtraInventoryRecord withUnlocked(boolean unlocked) {
         return new ExtraInventoryRecord(this.name, unlocked, ExtraInventorySavedData.copyItems(this.items));
      }

      private String nameOrUuid(UUID uuid) {
         return this.name.isBlank() ? uuid.toString() : this.name;
      }
   }
}
