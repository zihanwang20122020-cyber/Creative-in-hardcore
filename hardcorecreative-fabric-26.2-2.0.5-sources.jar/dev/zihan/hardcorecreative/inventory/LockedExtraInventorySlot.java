package dev.zihan.hardcorecreative.inventory;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public final class LockedExtraInventorySlot extends Slot {
   public LockedExtraInventorySlot(Container container, int slot, int x, int y) {
      super(container, slot, x, y);
   }

   public boolean mayPlace(ItemStack stack) {
      return false;
   }

   public boolean mayPickup(Player player) {
      return false;
   }
}
