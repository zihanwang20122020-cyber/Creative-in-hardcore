package dev.zihan.hardcorecreative.mixin;

import dev.zihan.hardcorecreative.permission.PermissionService;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.BaseCommandBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({BaseCommandBlock.class})
abstract class BaseCommandBlockPermissionMixin {
   @Redirect(
      method = {"performCommand"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/world/level/BaseCommandBlock;createCommandSourceStack(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/commands/CommandSource;)Lnet/minecraft/commands/CommandSourceStack;"
)
   )
   private CommandSourceStack hardcorecreative$elevateCommandBlockSource(BaseCommandBlock instance, ServerLevel level, CommandSource source) {
      CommandSourceStack commandSource = instance.createCommandSourceStack(level, source);
      return PermissionService.get().augmentCommandSource(commandSource);
   }
}
