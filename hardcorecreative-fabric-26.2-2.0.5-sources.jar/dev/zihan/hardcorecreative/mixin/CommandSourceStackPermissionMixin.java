package dev.zihan.hardcorecreative.mixin;

import dev.zihan.hardcorecreative.permission.PermissionService;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.permissions.PermissionSet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({CommandSourceStack.class})
abstract class CommandSourceStackPermissionMixin {
   @Inject(
      method = {"permissions"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void hardcorecreative$augmentCommandPermissions(CallbackInfoReturnable<PermissionSet> cir) {
      CommandSourceStack source = (CommandSourceStack)(Object)this;
      cir.setReturnValue(PermissionService.get().augmentCommandPermissions(source, (PermissionSet)cir.getReturnValue()));
   }
}
