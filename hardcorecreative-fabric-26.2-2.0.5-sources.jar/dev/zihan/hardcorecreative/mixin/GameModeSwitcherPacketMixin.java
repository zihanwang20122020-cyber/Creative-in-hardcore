package dev.zihan.hardcorecreative.mixin;

import dev.zihan.hardcorecreative.permission.PermissionService;
import net.minecraft.network.protocol.game.ServerboundChangeGameModePacket;
import net.minecraft.server.commands.GameModeCommand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ServerGamePacketListenerImpl.class})
abstract class GameModeSwitcherPacketMixin {
   @Shadow
   public ServerPlayer player;

   @Inject(
      method = {"handleChangeGameMode"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/network/protocol/PacketUtils;ensureRunningOnSameThread(Lnet/minecraft/network/protocol/Packet;Lnet/minecraft/network/PacketListener;Lnet/minecraft/server/level/ServerLevel;)V",
         shift = At.Shift.AFTER
      )},
      cancellable = true
   )
   private void hardcorecreative$allowAuthorizedGameModeSwitcher(ServerboundChangeGameModePacket packet, CallbackInfo ci) {
      if (PermissionService.get().canUseGameModeSwitcher(this.player)) {
         GameModeCommand.setGameMode(this.player, packet.mode());
         ci.cancel();
      }
   }
}
