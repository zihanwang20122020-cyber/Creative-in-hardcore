package dev.zihan.hardcorecreative.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Player.class})
abstract class PlayerGameMasterAccessClientMixin {
   @Inject(
      method = {"canUseGameMasterBlocks"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hardcorecreative$allowLocalCreativePlayer(CallbackInfoReturnable<Boolean> cir) {
      Player player = (Player)(Object)this;
      if (player.getAbilities().instabuild) {
         Minecraft minecraft = Minecraft.getInstance();
         if (minecraft.player == player) {
            cir.setReturnValue(true);
         }

      }
   }
}
