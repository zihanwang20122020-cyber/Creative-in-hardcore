package dev.zihan.hardcorecreative.mixin;

import dev.zihan.hardcorecreative.permission.PermissionNode;
import dev.zihan.hardcorecreative.permission.PermissionService;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Player.class})
abstract class PlayerGameMasterAccessMixin {
   @Inject(
      method = {"canUseGameMasterBlocks"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hardcorecreative$allowAuthorizedServerPlayers(CallbackInfoReturnable<Boolean> cir) {
      Player player = (Player)(Object)this;
      if (player.getAbilities().instabuild) {
         if (player instanceof ServerPlayer) {
            ServerPlayer serverPlayer = (ServerPlayer)player;
            if (PermissionService.get().has(serverPlayer, PermissionNode.COMMAND_SELF)) {
               cir.setReturnValue(true);
            }
         }

      }
   }
}
