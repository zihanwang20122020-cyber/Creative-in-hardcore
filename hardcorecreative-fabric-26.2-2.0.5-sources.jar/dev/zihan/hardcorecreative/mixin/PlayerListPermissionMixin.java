package dev.zihan.hardcorecreative.mixin;

import dev.zihan.hardcorecreative.permission.PermissionService;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.LevelBasedPermissionSet;
import net.minecraft.server.permissions.PermissionLevel;
import net.minecraft.server.players.PlayerList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({PlayerList.class})
abstract class PlayerListPermissionMixin {
   @Inject(
      method = {"sendPlayerPermissionLevel(Lnet/minecraft/server/level/ServerPlayer;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hardcorecreative$sendEffectivePermissionLevel(ServerPlayer player, CallbackInfo ci) {
      PlayerList playerList = (PlayerList)(Object)this;
      MinecraftServer server = playerList.getServer();
      LevelBasedPermissionSet vanilla = server.getProfilePermissions(player.nameAndId());
      LevelBasedPermissionSet effective = PermissionService.get().effectiveClientPermissionLevel(player, vanilla);
      if (effective != vanilla) {
         player.connection.send(new ClientboundEntityEventPacket(player, eventId(effective.level())));
         server.getCommands().sendCommands(player);
         ci.cancel();
      }
   }

   private static byte eventId(PermissionLevel level) {
      return switch (level) {
         case ALL -> 24;
         case MODERATORS -> 25;
         case GAMEMASTERS -> 26;
         case ADMINS -> 27;
         case OWNERS -> 28;
      };
   }
}
