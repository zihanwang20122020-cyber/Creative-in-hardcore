package dev.zihan.hardcorecreative.mixin;

import dev.zihan.hardcorecreative.permission.PermissionService;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.PermissionSet;
import net.minecraft.world.level.GameType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ServerPlayer.class})
abstract class ServerPlayerPermissionMixin {
   @Inject(
      method = {"permissions"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void hardcorecreative$augmentPlayerPermissions(CallbackInfoReturnable<PermissionSet> cir) {
      ServerPlayer player = (ServerPlayer)(Object)this;
      cir.setReturnValue(PermissionService.get().augmentPlayerPermissions(player, cir.getReturnValue()));
   }

   @Inject(
      method = {"setGameMode"},
      at = {@At("RETURN")}
   )
   private void hardcorecreative$rememberGameModeChange(GameType mode, CallbackInfoReturnable<Boolean> cir) {
      if (cir.getReturnValueZ()) {
         ServerPlayer player = (ServerPlayer)(Object)this;
         PermissionService.get().recordGameModeChange(player, mode);
      }
   }
}
