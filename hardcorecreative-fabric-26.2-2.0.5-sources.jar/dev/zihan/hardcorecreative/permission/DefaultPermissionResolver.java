package dev.zihan.hardcorecreative.permission;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

public final class DefaultPermissionResolver {
   public boolean has(CommandSourceStack source, PermissionNode node) {
      PermissionService service = PermissionService.get();
      if (!service.isCommandBlockSource(source) && !service.isConsoleSource(source)) {
         Entity entity = source.getEntity();
         if (entity instanceof ServerPlayer player) {
            return this.has(player, node);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean has(ServerPlayer player, PermissionNode node) {
      PermissionService service = PermissionService.get();
      boolean authorized = service.isAuthorized(player);
      boolean worldOwner = service.isWorldOwner(player);
      return switch (node) {
         case USE, BYPASS_HARDCORE_RESTRICTIONS, AUTO_RESTORE, COMMAND_SELF -> authorized;
         case ADMIN, COMMAND_OTHERS -> worldOwner;
      };
   }
}
