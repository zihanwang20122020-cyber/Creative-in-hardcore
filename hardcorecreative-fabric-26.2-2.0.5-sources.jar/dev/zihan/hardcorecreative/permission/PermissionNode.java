package dev.zihan.hardcorecreative.permission;

public enum PermissionNode {
   USE("hardcorecreative.use"),
   ADMIN("hardcorecreative.admin"),
   COMMAND_SELF("hardcorecreative.command.self"),
   COMMAND_OTHERS("hardcorecreative.command.others"),
   BYPASS_HARDCORE_RESTRICTIONS("hardcorecreative.bypass_hardcore_restrictions"),
   AUTO_RESTORE("hardcorecreative.auto_restore");

   private final String nodeId;

   private PermissionNode(String nodeId) {
      this.nodeId = nodeId;
   }

   public String nodeId() {
      return this.nodeId;
   }
}
