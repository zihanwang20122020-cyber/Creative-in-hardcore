package dev.zihan.hardcorecreative.permission;

import com.mojang.authlib.GameProfile;
import dev.zihan.hardcorecreative.ModConfig;
import dev.zihan.hardcorecreative.data.AuthorizedPlayersSavedData;
import dev.zihan.hardcorecreative.data.PlayerCreativeState;
import dev.zihan.hardcorecreative.data.WorldOwnerSavedData;
import dev.zihan.hardcorecreative.util.LogUtils;
import dev.zihan.hardcorecreative.util.ModeUtils;
import java.util.List;
import java.util.UUID;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.LevelBasedPermissionSet;
import net.minecraft.server.permissions.Permission;
import net.minecraft.server.permissions.PermissionLevel;
import net.minecraft.server.permissions.PermissionSet;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.server.players.NameAndId;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.GameType;

public final class PermissionService {
   private static final PermissionService INSTANCE = new PermissionService();
   private static final PermissionSet CREATIVE_COMMAND_PERMISSION_SET = PermissionService::isCreativeCommandPermission;
   private final DefaultPermissionResolver resolver = new DefaultPermissionResolver();

   private PermissionService() {
   }

   public static PermissionService get() {
      return INSTANCE;
   }

   public boolean has(CommandSourceStack source, PermissionNode node) {
      return this.resolver.has(source, node);
   }

   public boolean has(ServerPlayer player, PermissionNode node) {
      return this.resolver.has(player, node);
   }

   public boolean isAuthorized(ServerPlayer player) {
      MinecraftServer server = currentServer(player);
      return this.isActiveServer(server)
         && (this.isWorldOwner(player)
            || this.isAuthorized(server, player.getUUID())
            || this.isSingleplayerOwnerAutoAuthorized(player));
   }

   public boolean isAuthorized(MinecraftServer server, UUID playerUuid) {
      if (!this.isActiveServer(server) || playerUuid == null) {
         return false;
      }

      return WorldOwnerSavedData.get(server).isOwner(playerUuid)
         || AuthorizedPlayersSavedData.get(server).isAuthorized(playerUuid);
   }

   public boolean hasAdminLevel(ServerPlayer player) {
      return this.isWorldOwner(player);
   }

   public boolean isSingleplayerOwner(ServerPlayer player) {
      MinecraftServer server = currentServer(player);
      return server != null && server.isSingleplayerOwner(new NameAndId(player.getGameProfile()));
   }

   public boolean isWorldOwner(ServerPlayer player) {
      MinecraftServer server = currentServer(player);
      if (!this.isActiveServer(server)) {
         return false;
      }

      this.ensureWorldOwner(player);
      return WorldOwnerSavedData.get(server).isOwner(player.getUUID());
   }

   public boolean isSingleplayerOwnerAutoAuthorized(ServerPlayer player) {
      MinecraftServer server = currentServer(player);
      return this.isActiveServer(server) && ModConfig.autoAuthorizeSingleplayerOwner() && this.isSingleplayerOwner(player);
   }

   public boolean isConsoleSource(CommandSourceStack source) {
      if (source.getEntity() != null) {
         return false;
      }

      String sourceName = source.getTextName();
      return "Server".equalsIgnoreCase(sourceName) || "Rcon".equalsIgnoreCase(sourceName);
   }

   public boolean isCommandBlockSource(CommandSourceStack source) {
      return source.getEntity() == null && !this.isConsoleSource(source);
   }

   public PermissionSet augmentCommandPermissions(CommandSourceStack source, PermissionSet existingPermissions) {
      if (source == null || existingPermissions == null) {
         return existingPermissions;
      }

      Entity entity = source.getEntity();
      if (entity instanceof ServerPlayer player) {
         if (this.isWorldOwner(player)) {
            return PermissionSet.ALL_PERMISSIONS;
         }

         if (this.has(player, PermissionNode.COMMAND_SELF)) {
            return existingPermissions.union(CREATIVE_COMMAND_PERMISSION_SET);
         }
      }

      return existingPermissions;
   }

   public CommandSourceStack augmentCommandSource(CommandSourceStack source) {
      if (source == null) {
         return null;
      }

      Entity entity = source.getEntity();
      if (entity instanceof ServerPlayer player) {
         if (this.isWorldOwner(player)) {
            return source.withMaximumPermission(PermissionSet.ALL_PERMISSIONS);
         }

         if (this.has(player, PermissionNode.COMMAND_SELF)) {
            return source.withMaximumPermission(CREATIVE_COMMAND_PERMISSION_SET);
         }
      }

      return source;
   }

   public PermissionSet augmentPlayerPermissions(ServerPlayer player, PermissionSet existingPermissions) {
      if (player == null || existingPermissions == null) {
         return existingPermissions;
      }

      if (this.isWorldOwner(player)) {
         return PermissionSet.ALL_PERMISSIONS;
      }

      return this.isAuthorized(player) ? existingPermissions.union(LevelBasedPermissionSet.GAMEMASTER) : existingPermissions;
   }

   public LevelBasedPermissionSet effectiveClientPermissionLevel(ServerPlayer player, LevelBasedPermissionSet vanillaPermissions) {
      if (player == null || vanillaPermissions == null) {
         return vanillaPermissions;
      }

      if (this.isWorldOwner(player)) {
         return higherPermissionLevel(vanillaPermissions, LevelBasedPermissionSet.OWNER);
      }

      return this.isAuthorized(player) ? higherPermissionLevel(vanillaPermissions, LevelBasedPermissionSet.GAMEMASTER) : vanillaPermissions;
   }

   public boolean canUseGameModeSwitcher(ServerPlayer player) {
      return player != null && (this.isWorldOwner(player) || this.has(player, PermissionNode.COMMAND_SELF));
   }

   public void recordGameModeChange(ServerPlayer player, GameType mode) {
      if (player == null || mode == null || !this.isAuthorized(player)) {
         return;
      }

      MinecraftServer server = currentServer(player);
      if (mode == GameType.CREATIVE) {
         this.enableCreative(server, player.getGameProfile());
      } else {
         this.disableCreative(server, player.getGameProfile());
      }
   }

   public void grant(MinecraftServer server, GameProfile profile) {
      if (!this.isActiveServer(server)) {
         return;
      }

      AuthorizedPlayersSavedData.get(server).authorize(profile.id(), profile.name());
      PlayerCreativeState.get(server).ensureExists(profile.id(), profile.name());
      this.ensureLegacyAuthorizationMigrated(server);
      this.syncPlayerPermissionLevel(server, profile.id());
      LogUtils.debug("Granted hardcore creative access to {}", profile.name());
   }

   public void revoke(MinecraftServer server, UUID playerUuid) {
      if (!this.isActiveServer(server)) {
         return;
      }

      AuthorizedPlayersSavedData.get(server).revoke(playerUuid);
      PlayerCreativeState.get(server).remove(playerUuid);
      this.syncPlayerPermissionLevel(server, playerUuid);
      LogUtils.debug("Revoked hardcore creative access from {}", playerUuid);
   }

   public void enableCreative(MinecraftServer server, GameProfile profile) {
      if (!this.isActiveServer(server)) {
         return;
      }

      this.grant(server, profile);
      PlayerCreativeState.get(server).markEnabled(profile.id(), profile.name());
      this.syncPlayerPermissionLevel(server, profile.id());
   }

   public void disableCreative(MinecraftServer server, GameProfile profile) {
      if (!this.isActiveServer(server)) {
         return;
      }

      PlayerCreativeState.get(server).markDisabled(profile.id(), profile.name());
      this.syncPlayerPermissionLevel(server, profile.id());
   }

   public void onPlayerLogin(ServerPlayer player) {
      this.updateKnownIdentity(player);
      this.ensureSingleplayerOwnerAuthorization(player);
      this.applyCurrentPolicy(player, true);
      this.syncPlayerPermissionLevel(player);
   }

   public void onPlayerLogout(ServerPlayer player) {
      this.updateKnownIdentity(player);
   }

   public void onPlayerClone(ServerPlayer oldPlayer, ServerPlayer newPlayer) {
      this.updateKnownIdentity(newPlayer);
      if (this.isAuthorized(oldPlayer)) {
         MinecraftServer server = currentServer(newPlayer);
         if (server != null) {
            AuthorizedPlayersSavedData.get(server).authorize(newPlayer.getUUID(), newPlayer.getGameProfile().name());
         }
      }

      this.applyCurrentPolicy(newPlayer, false);
   }

   public void onPlayerChangedDimension(ServerPlayer player) {
      this.updateKnownIdentity(player);
      this.applyCurrentPolicy(player, false);
   }

   public void onPlayerTick(ServerPlayer player) {
      if (player.tickCount % 10 == 0) {
         this.applyCurrentPolicy(player, false);
      }
   }

   public void reapplyAll(MinecraftServer server) {
      this.ensureLegacyAuthorizationMigrated(server);

      for(ServerPlayer player : server.getPlayerList().getPlayers()) {
         this.applyCurrentPolicy(player, false);
         this.syncPlayerPermissionLevel(player);
      }
   }

   public void updateKnownIdentity(ServerPlayer player) {
      MinecraftServer server = currentServer(player);
      if (this.isActiveServer(server)) {
         AuthorizedPlayersSavedData.get(server).rememberName(player.getUUID(), player.getGameProfile().name());
         PlayerCreativeState.get(server).rememberName(player.getUUID(), player.getGameProfile().name());
      }
   }

   public boolean shouldRestoreCreative(ServerPlayer player) {
      MinecraftServer server = currentServer(player);
      if (!this.isActiveServer(server)) {
         return false;
      }

      return PlayerCreativeState.get(server)
         .get(player.getUUID())
         .map(state -> state.creativeRequested() && state.autoRestore())
         .orElse(false);
   }

   public String describeNode(ServerPlayer player, PermissionNode node) {
      return node.nodeId() + "=" + this.has(player, node);
   }

   private void ensureSingleplayerOwnerAuthorization(ServerPlayer player) {
      MinecraftServer server = currentServer(player);
      if (this.isActiveServer(server)) {
         this.ensureWorldOwner(player);
         this.ensureLegacyAuthorizationMigrated(server);
         if (ModConfig.autoAuthorizeSingleplayerOwner() && this.isWorldOwner(player)) {
            AuthorizedPlayersSavedData.get(server).authorize(player.getUUID(), player.getGameProfile().name());
            PlayerCreativeState.get(server).ensureExists(player.getUUID(), player.getGameProfile().name());
         }
      }
   }

   private boolean ensureWorldOwner(ServerPlayer player) {
      MinecraftServer server = currentServer(player);
      if (!this.isActiveServer(server)) {
         return false;
      }

      WorldOwnerSavedData ownerData = WorldOwnerSavedData.get(server);
      if (ownerData.hasOwner()) {
         return ownerData.isOwner(player.getUUID());
      }

      if (this.isSingleplayerOwner(player) || server.isDedicatedServer()) {
         ownerData.setOwner(player.getGameProfile());
         this.ensureLegacyAuthorizationMigrated(server);
      }

      return ownerData.isOwner(player.getUUID());
   }

   private void ensureLegacyAuthorizationMigrated(MinecraftServer server) {
      if (!this.isActiveServer(server)) {
         return;
      }

      WorldOwnerSavedData ownerData = WorldOwnerSavedData.get(server);
      if (!ownerData.hasOwner() || ownerData.legacyAuthorizationMigrated()) {
         return;
      }

      AuthorizedPlayersSavedData authorizedData = AuthorizedPlayersSavedData.get(server);
      UUID ownerUuid = ownerData.ownerUuid().orElse(null);
      if (ownerUuid == null) {
         return;
      }

      for(AuthorizedPlayersSavedData.AuthorizedEntry entry : List.copyOf(authorizedData.entries())) {
         if (!ownerUuid.equals(entry.uuid())) {
            authorizedData.revoke(entry.uuid());
            PlayerCreativeState.get(server).remove(entry.uuid());
         }
      }

      authorizedData.authorize(ownerUuid, ownerData.ownerName());
      PlayerCreativeState.get(server).ensureExists(ownerUuid, ownerData.ownerName());
      ownerData.markLegacyAuthorizationMigrated();
   }

   private void applyCurrentPolicy(ServerPlayer player, boolean notifyPlayer) {
      MinecraftServer server = currentServer(player);
      if (server == null) {
         return;
      }

      this.updateKnownIdentity(player);
      if (!ModConfig.allowCreativeAccess()) {
         if (ModeUtils.isCreative(player)) {
            ModeUtils.applySurvival(player);
            if (notifyPlayer) {
               player.sendSystemMessage(Component.literal("Hardcore Creative Access is disabled by config; you were returned to survival."));
            }
         }

         return;
      }

      if (this.isAuthorized(player)) {
         if (ModConfig.autoRestoreCreativeOnLogin() && this.shouldRestoreCreative(player) && !ModeUtils.isCreative(player)) {
            ModeUtils.applyCreative(player);
            if (notifyPlayer) {
               player.sendSystemMessage(Component.literal("Your creative access has been restored."));
            }
         }

         return;
      }

      if (ModeUtils.isCreative(player)) {
         ModeUtils.applySurvival(player);
         if (notifyPlayer) {
            player.sendSystemMessage(Component.literal("You are not authorized to stay in creative mode in this world."));
         }
      } else {
         ModeUtils.ensureSurvivalAbilities(player);
      }
   }

   private static MinecraftServer currentServer(ServerPlayer player) {
      return player.level().getServer();
   }

   private boolean isActiveServer(MinecraftServer server) {
      return server != null && ModConfig.allowCreativeAccess();
   }

   private void syncPlayerPermissionLevel(MinecraftServer server, UUID playerUuid) {
      if (server != null && playerUuid != null) {
         this.syncPlayerPermissionLevel(server.getPlayerList().getPlayer(playerUuid));
      }
   }

   private void syncPlayerPermissionLevel(ServerPlayer player) {
      MinecraftServer server = player == null ? null : currentServer(player);
      if (server != null) {
         server.getPlayerList().sendPlayerPermissionLevel(player);
      }
   }

   private static LevelBasedPermissionSet higherPermissionLevel(LevelBasedPermissionSet current, LevelBasedPermissionSet requested) {
      PermissionLevel currentLevel = current.level();
      PermissionLevel requestedLevel = requested.level();
      return currentLevel.isEqualOrHigherThan(requestedLevel) ? current : requested;
   }

   private static boolean isCreativeCommandPermission(Permission permission) {
      return permission == Permissions.COMMANDS_MODERATOR
         || permission == Permissions.COMMANDS_GAMEMASTER
         || permission == Permissions.COMMANDS_ENTITY_SELECTORS
         || permission == Permissions.CHAT_SEND_COMMANDS;
   }
}
