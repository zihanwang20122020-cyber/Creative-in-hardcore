package dev.zihan.hardcorecreative.util;

import dev.zihan.hardcorecreative.ModConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class LogUtils {
   private static final Logger LOGGER = LoggerFactory.getLogger("Hardcore Creative Access");

   private LogUtils() {
   }

   public static Logger logger() {
      return LOGGER;
   }

   public static void debug(String message, Object... args) {
      if (ModConfig.verboseLogging()) {
         LOGGER.info("[HardcoreCreative/Debug] " + message, args);
      }

   }
}
