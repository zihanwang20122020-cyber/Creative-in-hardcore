package dev.zihan.hardcorecreative.util;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;

public final class ModeUtils {
   private ModeUtils() {
   }

   public static boolean isHardcoreServer(MinecraftServer server) {
      return server != null && server.getWorldData().isHardcore();
   }

   public static GameType currentMode(ServerPlayer player) {
      return player.gameMode();
   }

   public static boolean isCreative(ServerPlayer player) {
      return currentMode(player) == GameType.CREATIVE;
   }

   public static void applyCreative(ServerPlayer player) {
      player.setGameMode(GameType.CREATIVE);
      player.onUpdateAbilities();
   }

   public static void applySurvival(ServerPlayer player) {
      player.setGameMode(GameType.SURVIVAL);
      ensureSurvivalAbilities(player);
   }

   public static void ensureSurvivalAbilities(ServerPlayer player) {
      if (player.getAbilities().flying) {
         player.getAbilities().flying = false;
      }

      player.onUpdateAbilities();
   }

   public static String modeName(ServerPlayer player) {
      return currentMode(player).getName();
   }
}
