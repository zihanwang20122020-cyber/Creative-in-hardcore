package dev.zihan.hardcorecreative.util;

import com.mojang.authlib.GameProfile;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.NameAndId;
import net.minecraft.server.players.UserNameToIdResolver;

public final class PlayerLookup {
   private PlayerLookup() {
   }

   public static Optional<ResolvedPlayer> resolve(MinecraftServer server, String input) {
      ServerPlayer online = server.getPlayerList().getPlayerByName(input);
      if (online != null) {
         return Optional.of(new ResolvedPlayer(online.getGameProfile(), online));
      } else {
         try {
            UUID uuid = UUID.fromString(input);
            ServerPlayer byUuid = server.getPlayerList().getPlayer(uuid);
            if (byUuid != null) {
               return Optional.of(new ResolvedPlayer(byUuid.getGameProfile(), byUuid));
            }

            UserNameToIdResolver cache = server.services().nameToIdCache();
            Optional<NameAndId> cachedByUuid = cache.get(uuid);
            if (cachedByUuid.isPresent()) {
               return Optional.of(fromNameAndId(server, (NameAndId)cachedByUuid.get()));
            }

            Optional<GameProfile> fetchedByUuid = server.services().profileResolver().fetchById(uuid);
            if (fetchedByUuid.isPresent()) {
               cache.add(new NameAndId((GameProfile)fetchedByUuid.get()));
               cache.save();
               return Optional.of(new ResolvedPlayer((GameProfile)fetchedByUuid.get(), (ServerPlayer)null));
            }
         } catch (IllegalArgumentException ignored) {
         }

         UserNameToIdResolver cache = server.services().nameToIdCache();
         Optional<NameAndId> cachedByName = cache.get(input);
         if (cachedByName.isPresent()) {
            return Optional.of(fromNameAndId(server, (NameAndId)cachedByName.get()));
         } else {
            Optional<GameProfile> fetchedByName = server.services().profileResolver().fetchByName(input);
            if (fetchedByName.isPresent()) {
               cache.add(new NameAndId((GameProfile)fetchedByName.get()));
               cache.save();
               return Optional.of(new ResolvedPlayer((GameProfile)fetchedByName.get(), server.getPlayerList().getPlayer(((GameProfile)fetchedByName.get()).id())));
            } else {
               return Optional.empty();
            }
         }
      }
   }

   private static ResolvedPlayer fromNameAndId(MinecraftServer server, NameAndId profile) {
      GameProfile resolvedProfile = new GameProfile(profile.id(), profile.name());
      return new ResolvedPlayer(resolvedProfile, server.getPlayerList().getPlayer(profile.id()));
   }

   public static record ResolvedPlayer(GameProfile profile, ServerPlayer onlinePlayer) {
      public boolean isOnline() {
         return this.onlinePlayer != null;
      }
   }
}
